/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referring to this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'PiX\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icn-user': '&#xe600;',
		'icn-think': '&#xe601;',
		'icn-dialogue': '&#xe602;',
		'icn-talk': '&#xe603;',
		'icn-tap': '&#xe604;',
		'icn-scroll': '&#xe605;',
		'icn-tap-2': '&#xe606;',
		'icn-scroll-2': '&#xe607;',
		'icn-slide': '&#xe608;',
		'icn-swipe-3': '&#xe609;',
		'icn-swipe': '&#xe60a;',
		'icn-pinch': '&#xe60b;',
		'icn-pinchin': '&#xe60c;',
		'icn-rotate': '&#xe60d;',
		'icn-hand': '&#xe60e;',
		'icn-collapse': '&#xe60f;',
		'icn-mouse': '&#xe610;',
		'icn-mouse-scroll': '&#xe611;',
		'icn-mouse-drag': '&#xe612;',
		'icn-mouse-right': '&#xe613;',
		'icn-mouse-left': '&#xe614;',
		'icn-mouse-all': '&#xe615;',
		'icn-keyboard': '&#xe616;',
		'icn-tab': '&#xe617;',
		'icn-enter': '&#xe618;',
		'icn-gear': '&#xe619;',
		'icn-loop': '&#xe61a;',
		'icn-upload': '&#xe61b;',
		'icn-download': '&#xe61c;',
		'icn-device-shake': '&#xe61d;',
		'icn-device-rotate': '&#xe61e;',
		'icn-device-orient': '&#xe61f;',
		'icn-compass': '&#xe620;',
		'icn-position': '&#xe621;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icn-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
